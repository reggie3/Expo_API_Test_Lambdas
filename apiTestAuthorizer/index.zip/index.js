'use strict';
var util = require('util');    // util enables deep looks into an object
var fetch = require('node-fetch');

console.log('Loading function');
const facebookClientSecret = process.env.facebookClientSecret;
const facebookAppID = process.env.facebookAppID;


exports.handler = (event, context, callback) => {
    // console.log(util.inspect(event, { showHidden: true, depth: null }));

    // use split to parse out the pieces of data in the authentication header
    let authorizationInfo = event.authorizationToken.split("||");
    let auth = {
        service: authorizationInfo[0],
        accessToken: authorizationInfo[1],
        id: authorizationInfo[2],
        email: authorizationInfo[3]
    }

    //console.log(util.inspect(auth, { showHidden: true, depth: null }));
    const token = auth.accessToken;
    console.log("access token = ", token);
    // Call oauth provider, crack jwt token, etc.
    // In this example, the token is treated as the status for simplicity.
    switch (auth.service) {
        case 'google':
            let googleVerificationResults = verifyGoogleToken(auth);
            console.log('********************');
            console.log({ googleVerificationResults });
            callback(null, generatePolicy('user', 'Allow', event.methodArn));
            break;
        case 'facebook':
            let facebookVerificationResults = verifyFacebookToken(auth);
            console.log('********************');
            console.log({ facebookVerificationResults });
            callback(null, generatePolicy('user', 'Allow', event.methodArn));
            break;
        default:
            callback(null, generatePolicy('user', 'Allow', event.methodArn));
            break;

    }
    /*switch (token.toLowerCase()) {
        case 'allow':
            callback(null, generatePolicy('user', 'Allow', event.methodArn));
            break;
        case 'deny':
            callback(null, generatePolicy('user', 'Deny', event.methodArn));
            break;
        case 'unauthorized':
            callback("Unauthorized");   // Return a 401 Unauthorized response
            break;
        default:
            callback("Error: Invalid token");
    }*/
};

// based on "Inspecting Access Tokens" from here: https://developers.facebook.com/docs/facebook-login/manually-build-a-login-flow#checktoken
let verifyFacebookToken = (auth) => {
    return new Promise(function (resolve, reject) {
        fetch(`https://graph.facebook.com/debug_token?input_token=${auth.accessToken}&access_token=${auth.accessToken}`, {
                method: 'GET'
            })
            .then((response) => {
                return response.json();
            })
            .then((json) => {
                console.log('***** verifyFacebookToken response ***');
                console.log({ json });
                if (json.hasOwnProperty('error')) {
                    reject({
                        type: 'error',
                    });
                }
                resolve(resolve({
                    type: 'success',
                }));
            })
            .catch(function (error) {
                console.log('Request failed', error);
                reject({
                    type: 'error',
                    msg: 'failed to verify facebook access token'
                });
            });
    });

}

// based on "OAUTH 2.0 ENDPOINTS" Complete Example from here: https://developers.google.com/identity/protocols/OAuth2UserAgent#validate-access-token
let verifyGoogleToken = (auth) => {
    return new Promise(function (resolve, reject) {
        fetch(`https://www.googleapis.com/oauth2/v3/tokeninfo?&access_token=${auth.accessToken}`, {
                method: 'POST'
            })
            .then((response) => {
                return response.json();
            })
            .then((json) => {
                console.log('***** verifyGoogleToken response ***');
                console.log({ json });
                if (json.hasOwnProperty('error')) {
                    reject({
                        type: 'error',
                    });
                }
                resolve(resolve({
                    type: 'success',
                }));
            })
            .catch(function (error) {
                console.log('Request failed', error);
                reject({
                    type: 'error',
                    msg: 'failed to verify google access token'
                });
            });
    });
}

var generatePolicy = function (principalId, effect, resource) {
    var authResponse = {};

    authResponse.principalId = principalId;
    if (effect && resource) {
        var policyDocument = {};
        policyDocument.Version = '2012-10-17'; // default version
        policyDocument.Statement = [];
        var statementOne = {};
        statementOne.Action = 'execute-api:Invoke'; // default action
        statementOne.Effect = effect;
        statementOne.Resource = resource;
        policyDocument.Statement[0] = statementOne;
        authResponse.policyDocument = policyDocument;
    }

    // Can optionally return a context object of your choosing.
    authResponse.context = {};
    authResponse.context.stringKey = "stringval";
    authResponse.context.numberKey = 123;
    authResponse.context.booleanKey = true;
    return authResponse;
}